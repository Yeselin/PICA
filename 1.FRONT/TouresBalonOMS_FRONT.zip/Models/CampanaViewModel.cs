﻿using System;
using System.ComponentModel;

namespace TouresBalonMVC.Models
{
    public class ProductoViewModel
    {
        [DisplayName("ID")]
        public long ID { get; set; }
        [DisplayName("Nombre")]
        public string Name { get; set; }
        [DisplayName("Fecha Espectáculo")]
        public DateTime Spectacle_date { get; set; }
        [DisplayName("Fecha Llegada")]
        public DateTime Arrival_date { get; set; }
        [DisplayName("Fecha Partida")]
        public DateTime Departure_date { get; set; }
        public long Transport_type { get; set; }
        public long Spectacle_type { get; set; }
        public long Lodging_type { get; set; }
        [DisplayName("Descripción")]
        public string Description { get; set; }
        [DisplayName("Code")]
        public string Code { get; set; }
        [DisplayName("Url Imagen")]
        public string Image_ref { get; set; }
        public long Source_city { get; set; }
        public long Target_city { get; set; }
        public DateTime Create_date { get; set; }
        public DateTime Update_date { get; set; }
        [DisplayName("Costo Total")]
        public decimal Cost_total { get; set; }
        [DisplayName("Transporte")]
        public string transporte { get; set; }
        [DisplayName("Hospedaje")]
        public string hospedaje { get; set; }
        [DisplayName("Espectáculo")]
        public string espectaculo { get; set; }
        [DisplayName("Ciudad Origen")]
        public string ciudadOrigen { get; set; }
        [DisplayName("Ciudad Destino")]
        public string ciudadDestino { get; set; }
        
    }
    public class ProductoDetalleViewModel
    {
        public long ID { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaEspectaculo { get; set; }
        public DateTime FechaLlegada { get; set; }
        public DateTime FechaPartida { get; set; }
        public string Transporte { get; set; }
        public long TransporteID { get; set; }
        public string Espectaculo { get; set; }
        public long EspectaculoID { get; set; }
        public string Hospedaje { get; set; }
        public long HospedajeID { get; set; }
        public string Descripcion { get; set; }
        public string Code { get; set; }
        public string Image_ref { get; set; }
        public string Origen { get; set; }
        public long OrigenID { get; set; }
        public string Destino { get; set; }
        public long DestinoID { get; set; }
        public DateTime FechaCreado { get; set; }
        public DateTime FechaActualizado  { get; set; }
        public decimal CostoTotal { get; set; }
    }
}