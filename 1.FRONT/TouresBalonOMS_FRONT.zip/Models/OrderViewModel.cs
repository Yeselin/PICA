﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace TouresBalonMVC.Models
{
    public class OrderViewModel
    {
        [DisplayName("ID Compra")]
        public long id { get; set; }
        [DisplayName("Fecha de Compra")]
        public DateTime order_date { get; set; }
        [DisplayName("Costo Total")]
        public long price_total { get; set; }
        [DisplayName("Estado")]
        public string status_name { get; set; }
        [DisplayName("Comentarios")]
        public string comments { get; set; }
        [DisplayName("Tipo Documento Cliente")]
        public string customer_document_type { get; set; }
        [DisplayName("# Documento Cliente")]
        public string customer_document_id { get; set; }
        [DisplayName("Fecha Actualizacion")]
        public DateTime update_date { get; set; }
        [DisplayName("ID Pago")]
        public string payment_id { get; set; }
        [DisplayName("Estado Compra")]
        public string payment_status { get; set; }
        [DisplayName("ID Producto")]
        public long product_id { get; set; }
        [DisplayName("Nombre Producto")]
        public string product_name { get; set; }
        [DisplayName("Numero de Parte")]
        public string partnum { get; set; }
        [DisplayName("Costo")]
        public long price { get; set; }
        [DisplayName("Cantidad")]
        public long quantity { get; set; }
    }
}