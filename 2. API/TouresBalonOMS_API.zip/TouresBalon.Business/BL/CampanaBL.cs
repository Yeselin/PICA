﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TouresBalon.Business.BO;
using TouresBalon.Datos.Clases.DAL;

namespace TouresBalon.Business.BL
{
    public class CampanaBL
    {
        private CampanaDAL dalProducto;
        public CampanaBL()
        {
            dalProducto = new CampanaDAL();
        }

        public object ListarCampana()
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalProducto.ObtenerListaCampana());
                List<CampanaBO> boCampana = JsonConvert.DeserializeObject<List<CampanaBO>>(lista).ToList();
                //return lista;
                return boCampana;
            }
            catch (Exception ex)
            {
                throw new  Exception(ex.Message);
            }
        }
    }
}
