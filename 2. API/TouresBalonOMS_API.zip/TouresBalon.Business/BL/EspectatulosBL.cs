﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using TouresBalon.Business.BO;
using TouresBalon.Datos.Clases.DAL;

namespace TouresBalon.Business.BL
{
    public class EspectaculosBL
    {
        private EspectaculosDAL dalEspectaculo;
        public EspectaculosBL()
        {
            dalEspectaculo = new EspectaculosDAL();
        }

        public object ListarEspectaculos()
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalEspectaculo.ListarEspectaculos());
                List<EspectaculoBO> boEspectaculos = JsonConvert.DeserializeObject<List<EspectaculoBO>>(lista).ToList();
                return boEspectaculos;
            }
            catch (Exception ex)
            {
                throw new  Exception(ex.Message);
            }
        }
    }
}
