﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using TouresBalon.Business.BO;
using TouresBalon.Datos.Clases.DAL;

namespace TouresBalon.Business.BL
{
    public class HospedajeBL
    {
        private HospedajeDAL dalHospedaje;
        public HospedajeBL()
        {
            dalHospedaje = new HospedajeDAL();
        }

        public object ListarHospedaje()
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalHospedaje.ListarHospedajes());
                List<HospedajeBO> boHospedaje = JsonConvert.DeserializeObject<List<HospedajeBO>>(lista).ToList();
                return boHospedaje;
            }
            catch (Exception ex)
            {
                throw new  Exception(ex.Message);
            }
        }
    }
}
