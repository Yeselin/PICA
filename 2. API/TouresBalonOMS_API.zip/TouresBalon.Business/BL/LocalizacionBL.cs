﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TouresBalon.Business.BO;
using TouresBalon.Datos.Clases.DAL;

namespace TouresBalon.Business.BL
{
    public class LocalizacionBL
    {
        private LocalizacionDAL dalLocalizacion;
        public LocalizacionBL()
        {
            dalLocalizacion = new LocalizacionDAL();
        }

        public object ListarLocalizacion()
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalLocalizacion.ListarLocalizacion());
                List<LocalizacionBO> boLocalizacion = JsonConvert.DeserializeObject<List<LocalizacionBO>>(lista).ToList();
                return boLocalizacion;
            }
            catch (Exception ex)
            {
                throw new  Exception(ex.Message);
            }
        }
    }
}
