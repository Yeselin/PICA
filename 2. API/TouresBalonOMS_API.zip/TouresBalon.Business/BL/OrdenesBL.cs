﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TouresBalon.Business.BO;
using TouresBalon.Datos.Clases.DAL;

namespace TouresBalon.Business.BL
{
    public class OrdenesBL
    {
        private OrdenesDAL dalordenes;
        public OrdenesBL()
        {
            dalordenes = new OrdenesDAL();
        }

        public object ListarOrdenes()
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalordenes.ObtenerListaOrdenes());
                if (!lista.Equals("null"))
                {
                    List<OrdenesBO> boOrdenes = JsonConvert.DeserializeObject<List<OrdenesBO>>(lista).ToList();
                    //return lista;
                    return boOrdenes;
                }
                else
                { return new List<OrdenesBO>(); }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
