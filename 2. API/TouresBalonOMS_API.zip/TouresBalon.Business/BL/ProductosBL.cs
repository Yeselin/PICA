﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using TouresBalon.Business.BO;
using TouresBalon.Datos.Clases.DAL;

namespace TouresBalon.Business.BL
{
    public class ProductosBL
    {
        private ProductosDAL dalProducto;
        public ProductosBL()
        {
            dalProducto = new ProductosDAL();
        }

        public object ListarProductosComodin(string comodin)
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalProducto.ObtenerProductosComodin(comodin));
                if (!lista.Equals("null"))
                {
                    List<ProductosBO> boProductos = JsonConvert.DeserializeObject<List<ProductosBO>>(lista).ToList();
                    //return lista;
                    return boProductos;
                }
                else
                { return new List<ProductosBO>(); }
            }
            catch (Exception ex)
            {
                throw new  Exception(ex.Message);
            }
        }
        public object ListarProductosPaginado(int pag)
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalProducto.ObtenerListaProductos(pag));
                if (!lista.Equals("null"))
                {
                    List<ProductosBO> boProductos = JsonConvert.DeserializeObject<List<ProductosBO>>(lista).ToList();
                    //return lista;
                    return boProductos;
                }
                else
                { return new List<ProductosBO>(); }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public object ProductosxID(long id)
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalProducto.ObtenerProductosIdentificador(id));
                if (!lista.Equals("null"))
                {
                    ProductosBO boProductos = JsonConvert.DeserializeObject<ProductosBO>(lista);
                    return boProductos;
                }
                else
                { return new List<ProductosBO>(); }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
