﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using TouresBalon.Business.BO;
using TouresBalon.Datos.Clases.DAL;

namespace TouresBalon.Business.BL
{
    public class TransporteBL
    {
        private TransporteDAL dalTransporte;
        public TransporteBL()
        {
            dalTransporte = new TransporteDAL();
        }

        public object ListarTransporte()
        {
            try
            {
                string lista = JsonConvert.SerializeObject(dalTransporte.ListarTransportes());
                List<TransporteBO> boTransporte = JsonConvert.DeserializeObject<List<TransporteBO>>(lista).ToList();
                return boTransporte;
            }
            catch (Exception ex)
            {
                throw new  Exception(ex.Message);
            }
        }
    }
}
