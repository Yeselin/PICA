﻿using TouresBalon.ICommons.DTO;

namespace TouresBalon.Business.BO
{
    public class CampanaBO : ICampana
    {
        public string ID { get ; set ; }
        public string Name { get ; set ; }
        public string Percentage { get ; set ; }
        public string Create_date { get ; set ; }
        public string Update_date { get ; set ; }
        public string Start_date { get ; set ; }
        public string Effective_date { get ; set ; }
        public string Image_ref { get ; set ; }
        public string Product_id { get ; set ; }
        public string Is_active { get ; set ; }
    }
}
