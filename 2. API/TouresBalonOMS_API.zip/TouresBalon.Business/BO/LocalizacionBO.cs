﻿using System;
using TouresBalon.ICommons.DTO;

namespace TouresBalon.Business.BO
{
    public class LocalizacionBO : ILocalizacion
    {
        public long ID { get; set; }
        public string Name_city { get; set; }
        public decimal Cost { get; set; }
        public string Country_name { get; set; }
        public string Country_short_name { get; set; }
        public DateTime Create_date { get; set; }
        public DateTime Update_date { get; set; }
    }
}
