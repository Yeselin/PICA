﻿using Newtonsoft.Json;
using System;
using TouresBalon.ICommons.DTO;

namespace TouresBalon.Business.BO
{
    public class ProductosBO 
    {
        [JsonProperty ("id")]
        public long ID { get; set;}


        [JsonProperty("name")]
        public string Name { get; set;}


        [JsonProperty("spectacle_date")]
        public DateTime Spectacle_date { get; set;}


        [JsonProperty("arrival_date")]
        public DateTime Arrival_date { get; set;}

        
        [JsonProperty("departure_date")]
        public DateTime Departure_date { get; set;}


        [JsonProperty("transport_type")]
        public long Transport_type { get; set;}


        [JsonProperty("spectacle_type")]
        public long Spectacle_type { get; set;}


        [JsonProperty("lodging_type")]
        public long Lodging_type { get; set;}


        [JsonProperty("description")]
        public string Description { get; set;}


        [JsonProperty("code")]
        public string Code { get; set;}


        [JsonProperty("image_ref")]
        public string Image_ref { get; set;}


        [JsonProperty("source_city")]
        public long Source_city { get; set;}


        [JsonProperty("target_city")]
        public long Target_city { get; set;}


        [JsonProperty("create_date")]
        public DateTime Create_date { get; set;}


        [JsonProperty("update_date")]
        public DateTime Update_date { get; set;}


        [JsonProperty("cost")]
        public decimal Cost_total { get; set;}

        public string transporte { get; set; }

        public string hospedaje { get; set; }
        public string espectaculo { get; set; }
        public string ciudadOrigen { get; set; }
        public string ciudadDestino { get; set; }

    }
}
