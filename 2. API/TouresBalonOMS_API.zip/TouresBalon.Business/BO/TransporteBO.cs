﻿using System;
using TouresBalon.ICommons.DTO;

namespace TouresBalon.Business.BO
{
    public class TransporteBO : ITransportesDTO
    {
        public long ID { get; set; }
        public string Name { get; set; }
        public decimal Cost { get; set; }
        public DateTime Create_date { get; set; }
        public DateTime Update_date { get; set; }
    }
}
