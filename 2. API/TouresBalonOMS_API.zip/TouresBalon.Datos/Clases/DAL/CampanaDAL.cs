﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using TouresBalon.Datos.Contexto;

namespace TouresBalon.Datos.Clases.DAL
{
    public class CampanaDAL
    {
        #region Atributos y propiedades
            private TouresBalonContexto ContextoDB;
        #endregion

        public CampanaDAL()
        {
            ContextoDB = new TouresBalonContexto();
        }

        public List<campana> ObtenerListaCampana()
        {
            try
            {
                string nombreSp = "CAMPANA_CONSULT";
                List<campana> listaCampana = ContextoDB.Database.SqlQuery<campana>(nombreSp).ToList();
                if (listaCampana.Any())
                {
                    return listaCampana;
                }
                else
                {
                    return  null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public List<campana> ObtenerCampanaComodin(string comodin)
        {
            try
            {
                string nombreSp = "PRODUCT_CONSULTA_COMODIN @NAME";
                List<campana> listaCampana = ContextoDB.Database.SqlQuery<campana>(nombreSp, new SqlParameter("@NAME", comodin)).ToList();
                if (listaCampana.Any())
                {
                    return listaCampana;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public campana ObtenerCampanaIdentificador(long ID)
        {
            try
            {
                string nombreSp = "CAMPANA_CONSULTA @ID";
                campana campana = ContextoDB.Database.SqlQuery<campana>(nombreSp, new SqlParameter("@ID", ID)).FirstOrDefault();
                if (campana !=null)
                {
                    return campana;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
