﻿using System.Collections.Generic;
using System.Linq;
using TouresBalon.Datos.Contexto;

namespace TouresBalon.Datos.Clases.DAL
{
    public class EspectaculosDAL
    {
        #region Atributos y propiedades
        private TouresBalonContexto ContextoDB;
        #endregion

        public EspectaculosDAL()
        {
            ContextoDB = new TouresBalonContexto();
        }
        public object ListarEspectaculos()
        {
            try
            {
                string nombreSp = "SPECTACLE_CONSULT";
                List<spectacle> listaEspectaculo = ContextoDB.Database.SqlQuery<spectacle>(nombreSp).ToList();
                if (listaEspectaculo.Any())
                {
                    return listaEspectaculo;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
