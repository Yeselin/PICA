﻿using System.Collections.Generic;
using System.Linq;
using TouresBalon.Datos.Contexto;

namespace TouresBalon.Datos.Clases.DAL
{
    public class HospedajeDAL
    {
        #region Atributos y propiedades
        private TouresBalonContexto ContextoDB;
        #endregion

        public HospedajeDAL()
        {
            ContextoDB = new TouresBalonContexto();
        }
        public object ListarHospedajes()
        {
            try
            {
                string nombreSp = "LODGING_CONSULT";
                List<lodging> listaHospedaje = ContextoDB.Database.SqlQuery<lodging>(nombreSp).ToList();
                if (listaHospedaje.Any())
                {
                    return listaHospedaje;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
