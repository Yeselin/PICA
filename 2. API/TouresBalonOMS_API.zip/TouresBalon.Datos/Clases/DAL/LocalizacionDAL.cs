﻿using System.Collections.Generic;
using System.Linq;
using TouresBalon.Datos.Contexto;

namespace TouresBalon.Datos.Clases.DAL
{
    public class LocalizacionDAL
    {
        #region Atributos y propiedades
        private TouresBalonContexto ContextoDB;
        #endregion

        public LocalizacionDAL()
        {
            ContextoDB = new TouresBalonContexto();
        }
        public object ListarLocalizacion()
        {
            try
            {
                string nombreSp = "CITY_CONSULT";
                List<city> listaLocalizacion = ContextoDB.Database.SqlQuery<city>(nombreSp).ToList();
                if (listaLocalizacion.Any())
                {
                    return listaLocalizacion;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
