﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TouresBalon.Datos.Contexto;

namespace TouresBalon.Datos.Clases.DAL
{
    public class OrdenesDAL
    {
        private TouresBalonContexto ContextoDB;
        public OrdenesDAL()
        {
            ContextoDB = new TouresBalonContexto();
        }

        public List<Ordenes> ObtenerListaOrdenes()
        {
            try
            {
                string nombreSp = "PR_ORDENES_CONSULT_TOTAL ";
                List<Ordenes> ListaOrdenes = ContextoDB.Database.SqlQuery<Ordenes>(nombreSp).ToList();
                if (ListaOrdenes.Any())
                {
                    return ListaOrdenes;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
