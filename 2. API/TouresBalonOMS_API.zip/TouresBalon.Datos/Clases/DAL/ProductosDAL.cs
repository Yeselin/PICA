﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using TouresBalon.Datos.Contexto;

namespace TouresBalon.Datos.Clases.DAL
{
    public class ProductosDAL
    {
        #region Atributos y propiedades
            private TouresBalonContexto ContextoDB;
        #endregion

        public ProductosDAL()
        {
            ContextoDB = new TouresBalonContexto();
        }

        public List<product> ObtenerListaProductos(int pag)
        {
            try
            {
                string nombreSp = "PR_PRODUCT_CONSULT_TOTAL @PagNum, @PagSize";
                List<product> listaProductos = ContextoDB.Database.SqlQuery<product>(nombreSp, new SqlParameter("@PagNum", pag), new SqlParameter("@PagSize",200)).ToList();
                if (listaProductos.Any())
                {
                    return listaProductos;
                }
                else
                {
                    return  null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public List<product> ObtenerProductosComodin(string comodin)
        {
            try
            {
                string nombreSp = "PR_PRODUCT_CONSULT_COMODIN @NAME";
                List<product> listaProductos = ContextoDB.Database.SqlQuery<product>(nombreSp, new SqlParameter("@NAME", comodin)).ToList();
                if (listaProductos.Any())
                {
                    return listaProductos;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }

        public product ObtenerProductosIdentificador(long ID)
        {
            try
            {
                string nombreSp = "PR_PRODUCT_CONSULTA_ID @ID";
                product producto = ContextoDB.Database.SqlQuery<product>(nombreSp, new SqlParameter("@ID", ID)).FirstOrDefault();
                if (producto !=null)
                {
                    return producto;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
