﻿using System.Collections.Generic;
using System.Linq;
using TouresBalon.Datos.Contexto;

namespace TouresBalon.Datos.Clases.DAL
{
    public class TransporteDAL
    {
        #region Atributos y propiedades
        private TouresBalonContexto ContextoDB;
        #endregion

        public TransporteDAL()
        {
            ContextoDB = new TouresBalonContexto();
        }
        public object ListarTransportes()
        {
            try
            {
                string nombreSp = "TRANSPORT_CONSULT";
                List<transport> listaTransporte = ContextoDB.Database.SqlQuery<transport>(nombreSp).ToList();
                if (listaTransporte.Any())
                {
                    return listaTransporte;
                }
                else
                {
                    return null;
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
