﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TouresBalon.Datos.Contexto
{
    public class Ordenes
    {
        public long id { get; set; }
        public DateTime order_date { get; set; }
        public long price_total { get; set; }
        public string status_name { get; set; }
        public string comments { get; set; }
        public string customer_document_type { get; set; }
        public string customer_document_id { get; set; }
        public DateTime update_date { get; set; }
        public string payment_id { get; set; }
        public string payment_status { get; set; }
        public long product_id { get; set; }
        public string product_name { get; set; }
        public string partnum { get; set; }
        public long price { get; set; }
        public long Quantity { get; set; }
    }
}
