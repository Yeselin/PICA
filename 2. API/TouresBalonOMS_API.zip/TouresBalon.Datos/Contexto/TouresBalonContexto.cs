namespace TouresBalon.Datos.Contexto
{
    using System.Data.Entity;

    public partial class TouresBalonContexto : DbContext
    {
        public TouresBalonContexto()
            : base(Properties.Settings.Default.StrConn)
        {
        }

        public virtual DbSet<campana> campanas { get; set; }
        public virtual DbSet<city> cities { get; set; }
        public virtual DbSet<city_backup> city_backup { get; set; }
        public virtual DbSet<lodging> lodgings { get; set; }
        public virtual DbSet<product> products { get; set; }
        public virtual DbSet<spectacle> spectacles { get; set; }
        public virtual DbSet<transport> transports { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<city>()
                .HasMany(e => e.products)
                .WithOptional(e => e.city)
                .HasForeignKey(e => e.source_city);

            modelBuilder.Entity<city>()
                .HasMany(e => e.products1)
                .WithOptional(e => e.city1)
                .HasForeignKey(e => e.target_city);

            modelBuilder.Entity<lodging>()
                .HasMany(e => e.products)
                .WithOptional(e => e.lodging)
                .HasForeignKey(e => e.lodging_type);

            modelBuilder.Entity<product>()
                .HasMany(e => e.campanas)
                .WithOptional(e => e.product)
                .HasForeignKey(e => e.product_id);

            modelBuilder.Entity<spectacle>()
                .HasMany(e => e.products)
                .WithOptional(e => e.spectacle)
                .HasForeignKey(e => e.spectacle_type);

            modelBuilder.Entity<transport>()
                .HasMany(e => e.products)
                .WithOptional(e => e.transport)
                .HasForeignKey(e => e.transport_type);
        }
    }
}
