namespace TouresBalon.Datos.Contexto
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("campana")]
    public partial class campana
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long id { get; set; }

        [StringLength(50)]
        public string name { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? percentage { get; set; }

        public DateTime? create_date { get; set; }

        public DateTime? update_date { get; set; }

        public DateTime? start_date { get; set; }

        public DateTime? effective_date { get; set; }

        [StringLength(500)]
        public string image_ref { get; set; }

        public long? product_id { get; set; }

        public int? is_active { get; set; }

        public virtual product product { get; set; }
    }
}
