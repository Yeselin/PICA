namespace TouresBalon.Datos.Contexto
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("product")]
    public partial class product
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public product()
        {
            campanas = new HashSet<campana>();
        }

        public long id { get; set; }

        [StringLength(50)]
        public string name { get; set; }

        [Column(TypeName = "date")]
        public DateTime? spectacle_date { get; set; }

        [Column(TypeName = "date")]
        public DateTime? arrival_date { get; set; }

        [Column(TypeName = "date")]
        public DateTime? departure_date { get; set; }

        public long? transport_type { get; set; }

        public long? spectacle_type { get; set; }

        public long? lodging_type { get; set; }

        [StringLength(100)]
        public string description { get; set; }

        [StringLength(20)]
        public string code { get; set; }

        [StringLength(500)]
        public string image_ref { get; set; }

        public long? source_city { get; set; }

        public long? target_city { get; set; }

        public DateTime? create_date { get; set; }

        public DateTime? update_date { get; set; }

        [Column(TypeName = "numeric")]
        public decimal? cost { get; set; }

        public int? status { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<campana> campanas { get; set; }

        public virtual city city { get; set; }

        public virtual city city1 { get; set; }

        public virtual lodging lodging { get; set; }

        public virtual spectacle spectacle { get; set; }

        public virtual transport transport { get; set; }

        public string transporte { get; set; }
        public string hospedaje { get; set; }
        public string espectaculo { get; set; }
        public string ciudadOrigen { get; set; }
        public string ciudadDestino { get; set; }
    }
}
