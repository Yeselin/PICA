﻿using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using TouresBalon.Business.BO;

namespace TouresBalonOMS.ProductosSoap
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IProductCreate" in both code and config file together.
    [ServiceContract]
    public interface IProductCreate
    {
        [OperationContract]
        OTProdutCreate CrearProducto(OTProdutCreate oTproduct);
    }

    [DataContract]
    public class OTProdutCreate
    {
        string messageResponse = "ok";

        [DataMember(IsRequired = false)]
        public string responseMSJ
        {
            get { return messageResponse; }
            set { messageResponse = value; }
        }

        [DataMember(IsRequired = true)]
        public long ID { get; set; }

        [DataMember(IsRequired = true)]
        public string NombreProducto { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime Fecha_Espectaculo { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime Fecha_llegada { get; set; }

        [DataMember(IsRequired = true)]
        public DateTime Fecha_Partida { get; set; }

        [DataMember(IsRequired = true)]
        public long Transporte { get; set; }

        [DataMember(IsRequired = true)]
        public long Espectaculo { get; set; }

        [DataMember(IsRequired = true)]
        public long Hospedaje { get; set; }

        [DataMember(IsRequired = true)]
        public string DescripcionEvento { get; set; }

        [DataMember(IsRequired = true)]
        public string CodigoProducto { get; set; }

        [DataMember(IsRequired = true)]
        public string ImagenURL { get; set; }

        [DataMember(IsRequired = true)]
        public long CiudadOrigen { get; set; }

        [DataMember(IsRequired = true)]
        public long CiudadDestino { get; set; }

        [DataMember(IsRequired = true)]
        public decimal Costo { get; set; }
    }
}
