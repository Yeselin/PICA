﻿using System.Runtime.Serialization;
using System.ServiceModel;

namespace TouresBalonOMS.ProductosSoap
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IProductDelete" in both code and config file together.
    [ServiceContract]
    public interface IProductDelete
    {
        [OperationContract]
        OTProductDelete EliminarProducto(OTProductDelete oTProduct);
    }
    public class OTProductDelete
    {
        string messageResponse = "ok";

        [DataMember(IsRequired = false)]
        public string responseMSJ
        {
            get { return messageResponse; }
            set { messageResponse = value; }
        }

        [DataMember(IsRequired = true)]
        public long ID { get; set; }

        [DataMember(IsRequired = true)]
        public string NombreProducto { get; set; }

        [DataMember(IsRequired = true)]
        public string CodigoProducto { get; set; }

    }
}
