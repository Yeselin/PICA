﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using TouresBalon.Business.BL;

namespace TouresBalonOMS.ConsultasWebApiRest.Controllers
{
    public class HospedajeController : ApiController
    {
        private HospedajeBL blHospeda;
        public HospedajeController()
        {
            blHospeda = new HospedajeBL();
        }
        // GET: api/Hospedaje
        public  Object Get()
        {
            return blHospeda.ListarHospedaje();
        }

        // GET: api/Hospedaje/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Hospedaje
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Hospedaje/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Hospedaje/5
        public void Delete(int id)
        {
        }
    }
}
