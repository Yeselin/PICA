﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using TouresBalon.Business.BL;


namespace TouresBalonOMS.ConsultasWebApiRest.Controllers
{
    public class LocalizacionController : ApiController
    {
        private LocalizacionBL blLocaliza;
        public LocalizacionController()
        {
            blLocaliza = new LocalizacionBL();
        }

        // GET: api/Localizacion
        public Object Get()
        {
            return blLocaliza.ListarLocalizacion();
        }

        // GET: api/Localizacion/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Localizacion
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Localizacion/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Localizacion/5
        public void Delete(int id)
        {
        }
    }
}
