﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TouresBalon.Business.BL;

namespace TouresBalonOMS.ConsultasWebApiRest.Controllers
{
    public class OrdenesController : ApiController
    {

        private OrdenesBL blOrdenes;
        public OrdenesController()
        {
            blOrdenes = new OrdenesBL();
        }


        [Route("api/ordenes")]
        public Object Get()
        {
            return blOrdenes.ListarOrdenes();
        }

        // GET: api/Ordenes/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Ordenes
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Ordenes/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Ordenes/5
        public void Delete(int id)
        {
        }
    }
}
