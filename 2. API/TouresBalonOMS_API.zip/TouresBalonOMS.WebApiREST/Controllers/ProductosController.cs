﻿using System;
using System.Web.Http;
using TouresBalon.Business.BL;

namespace TouresBalonOMS.ConsultasWebApiRest.Controllers
{
    public class ProductosController : ApiController
    {
        private ProductosBL blProductos;
        public ProductosController()
        {
            blProductos = new ProductosBL();
        }
        //[Route("api/Productos/{pagina}")]
        [Route("api/Productos")]
        public Object Get()
        {
            int pagina = 1;
            return blProductos.ListarProductosPaginado(pagina);
        }

        // GET: api/Productos/5
        [Route("api/Productos/comodin/{strcomodin}")]
        public Object Get(string strcomodin)
        {
            return blProductos.ListarProductosComodin(strcomodin);
        }

        [Route("api/productos/detalle/{id}")]
        public Object Get(long id)
        {
            return blProductos.ProductosxID(id);
        }
        // POST: api/Productos
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Productos/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Productos/5
        public void Delete(int id)
        {
        }
    }
}
