﻿using System;
using System.Web.Http;
using TouresBalon.Business.BL;

namespace TouresBalonOMS.ConsultasWebApiRest.Controllers
{
    public class TransporteController : ApiController
    {
        private TransporteBL blTransporte;
        public TransporteController()
        {
            blTransporte = new TransporteBL();
        }

        // GET: api/Transporte
        public Object Get()
        {
            return blTransporte.ListarTransporte();
        }

        // GET: api/Transporte/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Transporte
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Transporte/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Transporte/5
        public void Delete(int id)
        {
        }
    }
}
