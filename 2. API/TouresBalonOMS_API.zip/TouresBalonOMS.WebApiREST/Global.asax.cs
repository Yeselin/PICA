﻿using System.Web.Http;

namespace TouresBalonOMS.ConsultasWebApiRest
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            TouresBalon.Datos.Properties.Settings.Default["StrConn"] = System.Configuration.ConfigurationManager.AppSettings["StrConn"];
        }
    }
}
