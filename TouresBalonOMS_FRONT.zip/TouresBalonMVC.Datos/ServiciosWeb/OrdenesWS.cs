﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace TouresBalonMVC.Datos.ServiciosWeb
{
    public class OrdenesWS
    {
        public async Task<string> ConsultarOrdenes()
        {
            try
            {
                HttpClient client = new HttpClient();
                string direccion = string.Concat(Properties.Settings.Default.Conexion, "/api/Ordenes/");
                string datos = await client.GetStringAsync(direccion);
                return datos;
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
