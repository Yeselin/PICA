﻿using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;

namespace TouresBalonMVC.Datos.ServiciosWeb
{
    public class ProductosWS
    {
        public async Task<string> ConsultarProductos()
        {
            try
            {
                HttpClient client = new HttpClient();
                string direccion = string.Concat(Properties.Settings.Default.Conexion, "/api/Productos/");
                string datos = await client.GetStringAsync(direccion);
                return datos;
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
        public async Task<string> ConsultarProductosComodin(string comodin)
        {
            try
            {
                HttpClient client = new HttpClient();
                string direccion = string.Concat(Properties.Settings.Default.Conexion, "/api/Productos/comodin/", comodin);
                string datos = await client.GetStringAsync(direccion);
                return datos;
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
        public async Task<string> ConsultaDetalleProducto(long porductoID)
        {
            try
            {
                HttpClient client = new HttpClient();
                string direccion = string.Concat(Properties.Settings.Default.Conexion, "/api/Productos/detalle/", porductoID);
                string datos = await client.GetStringAsync(direccion);
                return datos;
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
        }
    }
}
