﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using TouresBalonMVC.Datos.ServiciosWeb;
using TouresBalonMVC.Models;

namespace TouresBalonMVC.Controllers
{
    public class ProductoController : Controller
    {
        private int indicePagina = 1;


        // GET: Producto
        public async Task<ActionResult> Index()
        {
            // traer la lista completa de productos
            ProductosWS serv = new ProductosWS();
            var lista = await serv.ConsultarProductos();
            var model = JsonConvert.DeserializeObject<List<ProductoViewModel>>(lista).ToList();
            //indicePagina++;
            return View(model);
        }
        
        // GET: Producto/Details/5
        public async Task<ActionResult> Details(int id)
        {
            ProductosWS serv = new ProductosWS();
            var lista = await serv.ConsultaDetalleProducto(id);
            var model = JsonConvert.DeserializeObject<ProductoViewModel>(lista);
           // indicePagina++;
            return View(model);
        }

        // GET: Producto/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Producto/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Producto/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Producto/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Producto/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Producto/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
